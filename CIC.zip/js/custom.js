/* JS */
$(function () {
  //    sticky navbar
  $(window).scroll(function () {
    var scrolling = $(this).scrollTop();
    var sticky = $(".navbar");
    if (scrolling >= 20) {
      sticky.addClass("navbg");
    } else {
      sticky.removeClass("navbg");
    }
  });
});
